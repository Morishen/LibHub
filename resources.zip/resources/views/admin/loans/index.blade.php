@extends('layouts.app')

@section('title', 'Kelola Peminjaman - Admin')

@section('content')
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h2 class="mb-1">
                <i class="bi bi-person-check-fill me-2 text-primary"></i>Kelola Peminjaman
            </h2>
            <p class="text-muted mb-0">Pantau dan kelola seluruh transaksi peminjaman buku perpustakaan.</p>
        </div>
        {{-- Menggunakan optional() atau ?? untuk menghindari error jika variabel kosong --}}
        <div class="badge bg-primary p-2 shadow-sm">
            Total Transaksi: {{ $loans->total() ?? 0 }}
        </div>
    </div>
    
    <div class="card border-0 shadow-sm mb-4">
        <div class="card-body">
            <form method="GET" action="{{ route('admin.loans.index') }}" class="row g-3">
                <div class="col-md-3">
                    <label class="form-label small fw-bold text-uppercase">Status Peminjaman</label>
                    <select name="status" class="form-select border-0 bg-light">
                        <option value="">Semua Status</option>
                        <option value="active" {{ request('status') == 'active' ? 'selected' : '' }}>Aktif (Dipinjam)</option>
                        <option value="overdue" {{ request('status') == 'overdue' ? 'selected' : '' }}>Terlambat</option>
                        <option value="returned" {{ request('status') == 'returned' ? 'selected' : '' }}>Selesai (Dikembalikan)</option>
                    </select>
                </div>
                <div class="col-md-7">
                    <label class="form-label small fw-bold text-uppercase">Cari Data</label>
                    <div class="input-group">
                        <span class="input-group-text bg-light border-0"><i class="bi bi-search"></i></span>
                        <input type="text" name="search" class="form-control border-0 bg-light" 
                               placeholder="Cari nama peminjam atau judul buku..." value="{{ request('search') }}">
                    </div>
                </div>
                <div class="col-md-2 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary w-100 shadow-sm">
                        <i class="bi bi-filter me-1"></i>Terapkan
                    </button>
                </div>
            </form>
        </div>
    </div>
    
    <div class="card border-0 shadow-sm overflow-hidden">
        <div class="card-body p-0">
            @if(isset($loans) && $loans->count() > 0)
                <div class="table-responsive">
                    <table class="table table-hover align-middle mb-0">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4 py-3">Peminjam</th>
                                <th>Informasi Buku</th>
                                <th>Durasi Pinjam</th>
                                <th>Status</th>
                                <th class="text-end pe-4">Aksi Admin</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach($loans as $loan)
                                <tr>
                                    <td class="ps-4">
                                        {{-- Perlindungan jika User telah dihapus --}}
                                        <div class="fw-bold text-dark">{{ $loan->user->name ?? 'User Terhapus' }}</div>
                                        <small class="text-muted">{{ $loan->user->email ?? '-' }}</small>
                                    </td>
                                    <td>
                                        <div class="d-flex align-items-center">
                                            <div class="bg-primary bg-opacity-10 p-2 rounded me-3">
                                                <i class="bi bi-book text-primary"></i>
                                            </div>
                                            <div>
                                                {{-- Perlindungan jika Buku telah dihapus --}}
                                                <div class="fw-bold text-dark">{{ $loan->book->title ?? 'Buku Tidak Ditemukan' }}</div>
                                                <small class="text-muted">ID: #{{ $loan->book_id }}</small>
                                            </div>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="small">
                                            {{-- Pastikan kolom tanggal sudah di-cast ke Carbon di Model Loan --}}
                                            <span class="text-muted">Pinjam:</span> {{ optional($loan->borrow_date)->format('d M Y') ?? '-' }}<br>
                                            <span class="text-muted">Batas:</span> 
                                            <span class="{{ ($loan->is_overdue && !$loan->returned_at) ? 'text-danger fw-bold' : '' }}">
                                                {{ optional($loan->due_date)->format('d M Y') ?? '-' }}
                                            </span>
                                        </div>
                                    </td>
                                    <td>
                                        @if($loan->returned_at)
                                            <span class="badge rounded-pill bg-success-soft text-success border border-success border-opacity-25 py-2 px-3">
                                                <i class="bi bi-check2-circle me-1"></i> Kembali: {{ $loan->returned_at->format('d/m/y') }}
                                            </span>
                                        @elseif($loan->is_overdue)
                                            <span class="badge rounded-pill bg-danger py-2 px-3 shadow-sm">
                                                <i class="bi bi-exclamation-triangle me-1"></i> Terlambat
                                            </span>
                                        @else
                                            <span class="badge rounded-pill bg-warning text-dark py-2 px-3">
                                                <i class="bi bi-clock-history me-1"></i> Dipinjam
                                            </span>
                                        @endif
                                    </td>
                                    <td class="text-end pe-4">
                                        @if(!$loan->returned_at)
                                            <form action="{{ route('admin.loans.return', $loan) }}" method="POST" class="d-inline ms-2">
                                                @csrf
                                                @method('PATCH') {{-- Gunakan PATCH untuk update status --}}
                                                <button type="submit" class="btn btn-sm btn-success px-3 shadow-sm" 
                                                        onclick="return confirm('Konfirmasi pengembalian buku ini?')">
                                                    <i class="bi bi-arrow-return-left me-1"></i>Kembalikan
                                                </button>
                                            </form>
                                        @else
                                            <button class="btn btn-sm btn-outline-secondary disabled border-0">
                                                <i class="bi bi-check-all me-1"></i>Selesai
                                            </button>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
                
                <div class="p-4 border-top bg-light bg-opacity-50 d-flex justify-content-between align-items-center">
                    <small class="text-muted">
                        Menampilkan <strong>{{ $loans->firstItem() }}</strong> - <strong>{{ $loans->lastItem() }}</strong> dari {{ $loans->total() }} data
                    </small>
                    <div>
                        {{ $loans->appends(request()->query())->links() }}
                    </div>
                </div>
            @else
                <div class="text-center py-5">
                    <div class="mb-3">
                        <i class="bi bi-search text-muted opacity-25" style="font-size: 5rem;"></i>
                    </div>
                    <h4 class="text-muted fw-light">Tidak ada data peminjaman</h4>
                    <p class="text-muted small">Coba ubah filter atau kata kunci pencarian Anda.</p>
                    <a href="{{ route('admin.loans.index') }}" class="btn btn-sm btn-outline-primary mt-2">Reset Filter</a>
                </div>
            @endif
        </div>
    </div>
</div>

<style>
    /* Styling tambahan untuk tampilan lebih modern */
    .bg-success-soft { background-color: rgba(25, 135, 84, 0.1); }
    .table thead th { 
        font-size: 0.75rem; 
        font-weight: 700;
        text-transform: uppercase; 
        letter-spacing: 0.8px;
        color: #6c757d;
    }
    .pagination { margin-bottom: 0; }
    .card { border-radius: 12px; }
    .form-select, .form-control { padding: 0.6rem 1rem; }
</style>
@endsection