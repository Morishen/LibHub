<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Models\Book;
use App\Models\Category;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

class BookController extends Controller
{
    public function index(Request $request)
    {
        $query = Book::with('category');

        if ($request->filled('search')) {
            $query->where(function($q) use ($request) {
                $q->where('title', 'like', '%' . $request->search . '%')
                  ->orWhere('author', 'like', '%' . $request->search . '%')
                  ->orWhere('isbn', 'like', '%' . $request->search . '%');
            });
        }

        if ($request->filled('category')) {
            $query->where('category_id', $request->category);
        }

        $books = $query->latest()->paginate(10);
        $categories = Category::all();

        // Ambil statistik sederhana untuk widget di dashboard admin
        $stats = [
            'total_books' => Book::count(),
            'available_books' => Book::where('available_copies', '>', 0)->count(),
            'unavailable_books' => Book::where('available_copies', 0)->count(),
        ];

        // PERBAIKAN: Admin diarahkan ke folder admin/books/index
        if (Auth::check() && Auth::user()->role === 'admin') {
            return view('admin.books.index', compact('books', 'categories', 'stats'));
        }

        // Kalau bukan admin, arahkan ke katalog umum (asumsi folder catalog/index)
        // Jika belum ada, pastikan folder resources/views/catalog/index.blade.php tersedia
        return view('admin.books.index', compact('books', 'categories', 'stats'));
    }

    public function create()
    {
        $categories = Category::all();
        return view('admin.books.form', compact('categories'));
    }

    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|max:255',
            'isbn' => 'required|unique:books,isbn',
            'author' => 'required',
            'category_id' => 'required|exists:categories,id',
            'total_copies' => 'required|integer|min:1',
            'available_copies' => 'required|integer|min:0',
            'cover_image' => 'nullable|image|max:2048',
            'description' => 'nullable'
        ]);

        if ($request->hasFile('cover_image')) {
            $validated['cover_image'] = $request->file('cover_image')->store('covers', 'public');
        }

        Book::create($validated);
        return redirect()->route('admin.books.index')->with('success', 'Buku berhasil disimpan!');
    }

    public function edit(Book $book)
    {
        $categories = Category::all();
        return view('admin.books.form', compact('book', 'categories'));
    }

    public function update(Request $request, Book $book)
    {
        $validated = $request->validate([
            'title' => 'required|max:255',
            'isbn' => 'required|unique:books,isbn,'.$book->id,
            'author' => 'required',
            'category_id' => 'required|exists:categories,id',
            'total_copies' => 'required|integer|min:1',
            'available_copies' => 'required|integer|min:0',
            'cover_image' => 'nullable|image|max:2048',
            'description' => 'nullable'
        ]);

        if ($request->hasFile('cover_image')) {
            if ($book->cover_image) Storage::disk('public')->delete($book->cover_image);
            $validated['cover_image'] = $request->file('cover_image')->store('covers', 'public');
        }

        $book->update($validated);
        return redirect()->route('admin.books.index')->with('success', 'Buku berhasil diperbarui!');
    }

    public function destroy(Book $book)
    {
        if ($book->cover_image) Storage::disk('public')->delete($book->cover_image);
        $book->delete();
        return redirect()->route('admin.books.index')->with('success', 'Buku berhasil dihapus!');
    }

    public function show(Book $book)
    {
        $book->load(['category']);
        
        $recentLoans = collect(); 
        if(Auth::check() && Auth::user()->role === 'admin') {
            // Gunakan try-catch atau check class supaya ga error kalau model Loan belum ada
            if (class_exists('\App\Models\Loan')) {
                $recentLoans = \App\Models\Loan::with('user')
                                ->where('book_id', $book->id)
                                ->latest()
                                ->take(5)
                                ->get();
            }
        }

        // PERBAIKAN: Di image_a5a48a.png error karena view 'books.show' ga ketemu.
        // Ubah ke lokasi file yang benar, biasanya 'admin.books.show'
        return view('catalog.show', compact('book', 'recentLoans'));
    }
}