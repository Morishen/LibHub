<?php

namespace App\Http\Controllers;

use App\Models\Loan;
use App\Models\Book;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoanController extends Controller
{
    /**
     * DASHBOARD MEMBER: Menampilkan statistik personal dan 5 pinjaman terakhir.
     */
    public function dashboard()
    {
        $user = Auth::user();
        
        // Proteksi: Jika admin nyasar ke sini, arahkan ke dashboard admin
        if ($user->is_admin) {
            return redirect()->route('admin.dashboard');
        }

        $loans = Loan::with(['book'])
            ->where('user_id', $user->id)
            ->latest('borrow_date')
            ->paginate(5);
        
        $stats = $this->getStats($user->id); 

        return view('dashboard.member.index', array_merge([
            'loans' => $loans,
        ], $stats));
    }

    /**
     * DASHBOARD ADMIN: Menampilkan statistik global seluruh perpustakaan.
     */
    public function adminDashboard()
    {
        $loans = Loan::with(['book', 'user'])
            ->latest('borrow_date')
            ->paginate(5); 
        
        $stats = $this->getAdminStats(); 

        return view('admin.dashboard', array_merge([
            'loans' => $loans,
        ], $stats));
    }

    /**
     * INDEX MEMBER: Riwayat peminjaman lengkap milik user sendiri.
     */
    public function index(Request $request)
    {
        $user = Auth::user();
        $query = Loan::with(['book'])->where('user_id', $user->id)->latest('borrow_date');

        $this->applyFilter($query, $request);

        $loans = $query->paginate(15);
        $stats = $this->getStats($user->id);

        return view('loans.index', array_merge([
            'loans' => $loans,
        ], $stats));
    }

    /**
     * INDEX ADMIN: Kelola semua peminjaman dari semua user.
     */
    public function adminIndex(Request $request)
    {
        $query = Loan::with(['book', 'user'])->latest('borrow_date');

        $this->applyFilter($query, $request);

        $loans = $query->paginate(15);
        $stats = $this->getAdminStats();

        return view('admin.loans.index', array_merge([
            'loans' => $loans,
        ], $stats));
    }

    /**
     * Method Helper: Filter Status (Active/Overdue) agar kode tidak duplikat.
     */
    private function applyFilter($query, $request)
    {
        if ($request->status === 'active') {
            $query->whereNull('returned_at')->whereDate('due_date', '>=', now());
        } elseif ($request->status === 'overdue') {
            $query->whereNull('returned_at')->whereDate('due_date', '<', now());
        }
    }

    /**
     * Method Helper: Statistik MEMBER.
     */
    private function getStats($userId)
    {
        return [
            'activeLoansCount' => Loan::where('user_id', $userId)
                ->whereNull('returned_at')->whereDate('due_date', '>=', now())->count(),
            'completedLoansCount' => Loan::where('user_id', $userId)
                ->whereNotNull('returned_at')->count(),
            'overdueLoansCount' => Loan::where('user_id', $userId)
                ->whereNull('returned_at')->whereDate('due_date', '<', now())->count(),
        ];
    }

    /**
     * Method Helper: Statistik ADMIN.
     */
    private function getAdminStats()
    {
        return [
            'activeLoansCount' => Loan::whereNull('returned_at')->whereDate('due_date', '>=', now())->count(),
            'completedLoansCount' => Loan::whereNotNull('returned_at')->count(),
            'overdueLoansCount' => Loan::whereNull('returned_at')->whereDate('due_date', '<', now())->count(),
            'totalBooksCount' => Book::count(),
            'totalUsersCount' => User::where('is_admin', 0)->count(),
        ];
    }

    /**
     * STORE: Member meminjam buku.
     */
    public function store(Request $request)
    {
        $request->validate(['book_id' => 'required|exists:books,id']);
        $book = Book::findOrFail($request->book_id);

        if ($book->available_copies <= 0) {
            return back()->with('error', 'Maaf, stok buku ini sedang habis.');
        }

        Loan::create([
            'user_id' => Auth::id(),
            'book_id' => $book->id,
            'borrow_date' => now(),
            'due_date' => now()->addDays(7),
        ]);

        $book->decrement('available_copies');

        return redirect()->route('dashboard')->with('success', 'Buku berhasil dipinjam!');
    }

    /**
     * RETURN: Admin memproses pengembalian buku.
     */
    public function returnBook(Loan $loan)
    {
        if ($loan->returned_at) {
            return back()->with('info', 'Buku ini sudah dikembalikan.');
        }

        $loan->update(['returned_at' => now()]);
        $loan->book->increment('available_copies');

        return back()->with('success', 'Buku telah berhasil dikembalikan.');
    }
}